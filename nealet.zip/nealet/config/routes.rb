Rails.application.routes.draw do

  get 'toilets/new' => "toilets#new"
  get 'users/new' => "users#new"
  get 'top' => "home#top"
  get 'search' => "home#search"
  get 'search_nearlet' => "home#search_nealet"

end
