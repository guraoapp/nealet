module ToiletsHelper
end
