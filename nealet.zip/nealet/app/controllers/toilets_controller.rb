class ToiletsController < ApplicationController
  def new
  end
end
