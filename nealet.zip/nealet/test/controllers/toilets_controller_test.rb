require 'test_helper'

class ToiletsControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get toilets_new_url
    assert_response :success
  end

end
